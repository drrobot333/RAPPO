import os
import time
import random
import argparse
import numpy as np
from tqdm import tqdm
import librosa
import librosa.display
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F

from lipreading.utils import get_save_folder
from lipreading.utils import load_json, save2npz
from lipreading.utils import load_model, CheckpointSaver
from lipreading.utils import get_logger, update_logger_batch
from lipreading.utils import showLR, calculateNorm2, AverageMeter
from lipreading.model import Lipreading
from lipreading.models.FCN import FCN
from lipreading.mixup import mixup_data, mixup_criterion
from lipreading.optim_utils import get_optimizer, CosineScheduler
from lipreading.dataloaders import get_data_loaders, get_preprocessing_pipelines

def train(model):

    input = torch.randn(32,29,44,44)

    fcn = FCN()

    logits = model(input.unsqueeze(1), lengths=[30]*32, boundaries=None)
    # logits = model(input.unsqueeze(1).cuda(), lengths=[29], boundaries=None)
    print("logits", logits.shape)
    # torch.Size([32, 29, 512])
    # logits = logits.unsqueeze(dim=1)
    a = fcn(logits)
    print("a", a.shape) #is model working properly?

    #######################################################################################
    audio = np.random.rand(15999)
    sr = 16000
    n_mels = 128
    n_fft = 2048
    hop_length = 125

    mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr, n_fft=n_fft, hop_length=hop_length, n_mels=n_mels)
    mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
    mel_spec_tensor = torch.from_numpy(mel_spec_db)

    print(mel_spec_db.shape)
    #######################################################################################
    
    mask = a[0,0]
    print(mask.shape)
    mask = torch.ones((128,128))

    masked_mel_spec_db = torch.mul(mask, mel_spec_tensor).detach().numpy()

    print(masked_mel_spec_db.shape)
    

    # plot the mel-spectrogram using matplotlib
    plt.figure(figsize=(10, 10))
    librosa.display.specshow(masked_mel_spec_db, x_axis='time', y_axis='mel', sr=sr, hop_length=hop_length)
    #plt.colorbar(format='%+2.0f dB')
    plt.title('Mel-Spectrogram')
    plt.tight_layout()
    plt.show()

parser = argparse.ArgumentParser(description='Pytorch Lipreading ')

parser.add_argument('--tcn-kernel-size', type=int, nargs="+", help='Kernel to be used for the TCN module')
parser.add_argument('--tcn-num-layers', type=int, default=4, help='Number of layers on the TCN module')
parser.add_argument('--tcn-dropout', type=float, default=0.2, help='Dropout value for the TCN module')
parser.add_argument('--tcn-dwpw', default=False, action='store_true', help='If True, use the depthwise seperable convolution in TCN architecture')
parser.add_argument('--tcn-width-mult', type=int, default=1, help='TCN width multiplier')

tcn_options = { 'num_layers': 4,
                        'kernel_size': [3, 5, 7, 9],
                        'dropout': 0.2,
                        'dwpw': False,
                        'width_mult': 1,
                      }

model = Lipreading( modality="video",
                        num_classes=500,
                        tcn_options=tcn_options,
                        densetcn_options={},
                        backbone_type="resnet",
                        relu_type='relu',
                        width_mult=1.0,
                        use_boundary=False,
                        extract_feats=False)

# model = model.cuda()

calculateNorm2(model)

train(model)

"""
def train():
  audio = np.random.rand(16000)
  sr = 16000
  n_mels = 128
  n_fft = 2048
  hop_length = 512  

  mel_spec = librosa.feature.melspectrogram(y=audio, sr=sr, n_fft=n_fft, hop_length=hop_length, n_mels=n_mels)
  mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)

  print(mel_spec_db.shape)
  

  # plot the mel-spectrogram using matplotlib
  plt.figure(figsize=(10, 4))
  librosa.display.specshow(mel_spec_db, x_axis='time', y_axis='mel', sr=sr, hop_length=hop_length)
  #plt.colorbar(format='%+2.0f dB')
  plt.title('Mel-Spectrogram')
  plt.tight_layout()
  plt.show()



train()
"""