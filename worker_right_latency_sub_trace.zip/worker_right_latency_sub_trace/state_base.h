/*
 * state.h
 *
 *  Created on: 2022. 7. 20.
 *      Author: user
 */

#ifndef STATE_H_
#define STATE_H_

class state_base{
public:
    double* state;
    double remain;
    double progress;
    double total_latency;
    double reward;
    double allJobWait;
    double allJobWaitTime;
    double power;
    int completeNum;
    int currentProcessing;
    int num;
    int order;

    state_base(double* state, double remain, double progress, int currentProcessing, int num, int order, int completeNum, double reward, double allJobWait, double allJobWaitTime, double power, double total_latency);

    int getCurrentProcessing() const {
        return currentProcessing;
    }

    void setCurrentProcessing(int currentProcessing) {
        this->currentProcessing = currentProcessing;
    }

    int getNum() const {
        return num;
    }

    void setNum(int num) {
        this->num = num;
    }

    double getProgress() const {
        return progress;
    }

    void setProgress(double progress) {
        this->progress = progress;
    }

    double getRemain() const {
        return remain;
    }

    void setRemain(double remain) {
        this->remain = remain;
    }

    double* getState() const {
        return state;
    }

    void setState(double *state) {
        this->state = state;
    }

    int getOrder() const {
        return order;
    }

    void setOrder(int order) {
        this->order = order;
    }

    int getCompleteNum() const {
        return completeNum;
    }

    double getReward() const {
        return reward;
    }

    double getAllJobWait() const {
        return allJobWait;
    }

    void setAllJobWait(double allJobWait) {
        this->allJobWait = allJobWait;
    }

    double getAllJobWaitTime() const {
        return allJobWaitTime;
    }

    void setAllJobWaitTime(double allJobWaitTime) {
        this->allJobWaitTime = allJobWaitTime;
    }

    double getPower() const {
        return power;
    }

    void setPower(double power) {
        this->power = power;
    }

    double getTotal_latency() const {
        return total_latency;
    }
};



#endif /* STATE_H_ */
