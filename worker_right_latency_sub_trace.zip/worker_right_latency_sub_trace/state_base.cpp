/*
 * state.cpp
 *
 *  Created on: 2022. 7. 20.
 *      Author: user
 */




#include "state_base.h"

state_base::state_base(double* state, double remain, double progress, int currentProcessing, int num, int order, int completeNum, double reward, double allJobWait, double allJobWaitTime, double power, double total_latency){
        this->state = state;
        this->remain = remain;
        this->progress = progress;
        this->currentProcessing = currentProcessing;
        this->num = num;
        this->order = order;
        this->completeNum = completeNum;
        this->reward = reward;
        this->allJobWait = allJobWait;
        this->allJobWaitTime = allJobWaitTime;
        this->power = power;
        this->total_latency = total_latency;
    }
